define(["base/js/namespace","base/js/utils"], function(__WEBPACK_EXTERNAL_MODULE_2__, __WEBPACK_EXTERNAL_MODULE_3__) { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	var modify_common_html = __webpack_require__(1);

	function load_ipython_extension(){
	    console.log('Linker extension (common) loaded');

	    modify_common_html.load();
	}

	module.exports = {load_ipython_extension: load_ipython_extension};


/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(2),__webpack_require__(3)], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,utils){

	    var load = function() {
	        var header_containter = $("#header-container").detach();
	        var header_containter_container = $("<div/>")
	                                          .attr("id","header-container-container")
	                                          .addClass("container");

	        header_containter_container.append(header_containter);
	        $("#header").prepend(header_containter_container);

	        var file_tree_button = $("<a/>")
	                               .addClass("btn btn-default btn-sm navbar-btn" 
	                                         + "pull-right file-tree-button")
	                               .css("margin-right","2px")
	                               .css("margin-left","2px")
	                               .attr("href",utils.get_body_data("baseUrl"))
	                               .text("File Tree");

	        $("#login_widget").after(file_tree_button);
	        
	        var logo_link = $("#ipython_notebook").children("a");
	        logo_link.attr("href","https://www.stfc.ac.uk/");

	        $("head").append(
	            $("<link>")
	            .attr("rel", "stylesheet")
	            .attr("type", "text/css")
	            .attr("href", utils.get_body_data("baseUrl")
	                          + "nbextensions/linker_extension/base/base_style.css")
	        );
	    };

	    module.exports = {load: load};
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ },
/* 2 */
/***/ function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_2__;

/***/ },
/* 3 */
/***/ function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_3__;

/***/ }
/******/ ])});;