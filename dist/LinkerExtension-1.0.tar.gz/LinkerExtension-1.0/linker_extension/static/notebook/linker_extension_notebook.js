define(["base/js/namespace","base/js/utils","base/js/dialog","notebook/js/celltoolbar","base/js/events"], function(__WEBPACK_EXTERNAL_MODULE_2__, __WEBPACK_EXTERNAL_MODULE_3__, __WEBPACK_EXTERNAL_MODULE_7__, __WEBPACK_EXTERNAL_MODULE_10__, __WEBPACK_EXTERNAL_MODULE_11__) { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(4);
	__webpack_require__(5);
	var add_metadata = __webpack_require__(6);
	var custom_cell_toolbar = __webpack_require__(9);
	var modify_notebook_html = __webpack_require__(8);
	var select_data_notebook = __webpack_require__(12);
	var upload_data = __webpack_require__(13);
	var upload_notebook = __webpack_require__(15);
	var view_data_dialog = __webpack_require__(14);
	var publish_notebook = __webpack_require__(16);
	var generate_references = __webpack_require__(17);


	function load_ipython_extension(){
	    console.log("Linker extension (notebook) loaded");

	    modify_notebook_html.load();
	    add_metadata.load();
	    select_data_notebook.load();
	    upload_data.load();
	    upload_notebook.load();
	    view_data_dialog.load();
	    custom_cell_toolbar.load();
	    publish_notebook.load();
	    generate_references.load();
	}

	module.exports = {load_ipython_extension: load_ipython_extension};


/***/ },
/* 1 */,
/* 2 */
/***/ function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_2__;

/***/ },
/* 3 */
/***/ function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_3__;

/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(2),__webpack_require__(3)], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,utils){
	    "use strict";

	    var get_collections = function() {
	        var url = utils.url_path_join.apply(null,[Jupyter.notebook.base_url,
	                                                  "/dspace"]);
	        var settings = {
	            type : "GET",
	            processData : false,
	            cache : false,
	        };
	        return utils.promising_ajax(url, settings);
	    };

	    var sword_new_item = function(data) {
	        var url = utils.url_path_join.apply(null,[Jupyter.notebook.base_url,
	                                                  "/sword"]);
	        var settings = {
	            type : "POST",
	            cache: false,
	            processData : false,
	            data: data,
	            contentType: "application/json",
	        };
	        return utils.promising_ajax(url, settings);
	    };

	    var upload_data = function(data) {
	        var url = utils.url_path_join.apply(null,[Jupyter.notebook.base_url,
	                                                  "/uploadbundle"]);
	        var settings = {
	            type : "POST",
	            processData : false,
	            data: data,
	            contentType: "application/json",
	        };
	        return utils.promising_ajax(url, settings);
	    };


	    var sword_get_servicedocument = function() {
	        var url = utils.url_path_join.apply(null,[Jupyter.notebook.base_url,
	                                                  "/sword"]);
	        var settings = {
	            processData : false,
	            cache : false,
	            type : "GET",
	        };
	        return utils.promising_ajax(url, settings);
	    };

	    var ldap_auth = function(data) {
	        var url = utils.url_path_join.apply(null,[Jupyter.notebook.base_url,
	                                                  "/ldap"]);
	        var settings = {
	            processData : false,
	            cache : false,
	            type : "POST",
	            data: data,
	            contentType: "application/json",
	        };
	        return utils.promising_ajax(url, settings);
	    };

	    module.exports = {
	        sword_get_servicedocument: sword_get_servicedocument,
	        get_collections: get_collections,
	        sword_new_item: sword_new_item,
	        upload_data: upload_data,
	        ldap_auth: ldap_auth,
	    };
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = function(){
	    "use strict";

	    function load_ipython_extension(){
	        console.log("Custom utils loaded");
	    }

	    var getParameterByName = function(name, url) {
	        if (!url) {
	            url = window.location.href;
	        }
	        name = name.replace(/[\[\]]/g, "\\$&");
	        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
	            results = regex.exec(url);
	        if (!results) return null;
	        if (!results[2]) return "";
	        return decodeURIComponent(results[2].replace(/\+/g, " "));
	    };

	    var create_alert = function(alert_type, message) {
	        var alert = $("<div/>")
	                            .addClass("alert alert-dismissible fade in")
	                            .addClass(alert_type)
	                            .attr("role","alert")
	                            .text(message)
	                            .append(
	                                $("<button/>")
	                                .addClass("close")
	                                .attr("type","button")
	                                .attr("data-dismiss","alert")
	                                .attr("aria-label","Close")
	                                .append($("<span/>").attr("aria-hidden","true")
	                                        .html("&times;")
	                                        )
	                            );
	                            
	        $("#header").after(alert);
	        return alert;
	    };

	    module.exports = {
	        getParameterByName : getParameterByName,
	        create_alert : create_alert,
	        load_ipython_extension: load_ipython_extension
	    };
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ },
/* 6 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(2),
	        __webpack_require__(3),
	        __webpack_require__(7),
	        __webpack_require__(4),
	        __webpack_require__(8)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,utils,dialog,custom_contents){

	    var add_metadata = function () {

	        var form_fields = create_fields();

	        var form_body = $("<div/>").attr("title", "Add the metadata")
	            .append(
	                $("<form/>").attr("id","add_metadata_form").append(
	                        $("<label/>")
	                        .attr("for","add_metadata_form")
	                        .text("Add the metadata for the notebook."))
	                        .append(form_fields.form1)
	                        .append(form_fields.form2)
	            );
	        
	        var modal = dialog.modal({
	            title: "Add " + Jupyter.notebook.notebook_name + " Metadata",
	            body: form_body,
	            buttons: {
	                Cancel: {},
	                Previous: { 
	                    click: function() {
	                        //make a multi page form by changing visibility of the forms
	                        if(!$("#fields1").hasClass("hide-me") &&
	                            $("#fields2").hasClass("hide-me"))
	                        { 
	                            //can't go back when we're on the first page
	                            $("#previous").addClass("disabled"); 
	                        }
	                        else if($("#fields1").hasClass("hide-me") &&
	                                !$("#fields2").hasClass("hide-me"))
	                        {
	                            $("#fields2").addClass("hide-me");
	                            $("#fields1").removeClass("hide-me");
	                            //we want button text to be next on any page
	                            //but the last one
	                            $("#next").text("Next"); 
	                        }
	                    }
	                },
	                Next: { 
	                    class : "btn-primary",
	                    click: function() {
	                        validate();
	                    },
	                }
	            },
	            notebook: Jupyter.notebook,
	            keyboard_manager: Jupyter.notebook.keyboard_manager,
	        });

	        modal.on("shown.bs.modal", function () {
	            $(".modal-footer > button.btn-sm").eq(1).removeAttr("data-dismiss")
	                                                    .attr("id","previous");
	            $(".modal-footer > button.btn-sm").eq(2).removeAttr("data-dismiss")
	                                                    .attr("id","next");
	        });
	    };

	    var create_fields = function () {
	        var md = Jupyter.notebook.metadata;
	        var md_set = false;
	        var authorcount = 1;

	        var return_fields = {};

	        //check to see if metadata has previously been set and whether we need
	        //to repopulate the form fields
	        if(md.hasOwnProperty("reportmetadata")) { 
	            md_set = true;
	        }

	        var title = $("<input/>")
	            .attr("name","title")
	            .attr("id","title")
	            .attr("type","text")
	            .val("");

	        return_fields.title = title;

	        var titleLabel =  $("<label/>")
	            .attr("for","title")
	            .text("Title: ");

	        var defaultAuthorFirstName = $("<input/>")
	            .attr("class","author-first-name")
	            .attr("type","text")
	            .attr("id","author-first-name-0")
	            .on("keydown", function(event) {
	                if (event.keyCode === $.ui.keyCode.TAB &&
	                    $(this).autocomplete().data("ui-autocomplete").menu.active)
	                {
	                    event.preventDefault(); //don't navigate away on tab press
	                }
	            })
	            .autocomplete({
	                source: function( request, response ) {
	                    var url = Jupyter.notebook.contents.base_url + "ldap";
	                    var settings = {
	                        processData : false,
	                        cache: false,
	                        type : "GET",
	                        dataType : "json",
	                        success: function(data) {
	                            response($.map(data, function(item) {
	                                var parsed = JSON.parse(item);
	                                var sn = parsed.attributes.sn;
	                                var fn = parsed.attributes.givenName;
	                                var namestring = sn + ", " + fn;
	                                return namestring;
	                            }));
	                        }
	                    };
	                    $.ajax(url + "?" + 
	                           $.param({"firstname": request.term,
	                                    "lastname": $("#author-last-name-0").val()}
	                          ),settings);
	                },
	                focus: function() {
	                  // prevent value inserted on focus
	                    return false;
	                },
	                select: function( event, ui ) {
	                    var name = ui.item.value;
	                    var sn = name.split(",")[0].trim();
	                    var fn = name.split(",")[1].trim();
	                    $(this).val(fn);
	                    $(this).parent().children().eq(0).val(sn);
	                    return false;
	                },
	                minLength:1,
	            });

	        var defaultAuthorLastName = $("<input/>")
	            .attr("class","author-last-name")
	            .attr("type","text")
	            .attr("id","author-last-name-0")
	            .on("keydown", function(event) {
	                if (event.keyCode === $.ui.keyCode.TAB &&
	                    $(this).autocomplete().data("ui-autocomplete").menu.active)
	                {
	                    event.preventDefault();
	                }
	            })
	            .autocomplete({
	                source: function( request, response ) {
	                    var url = Jupyter.notebook.contents.base_url + "ldap";
	                    var settings = {
	                        processData : false,
	                        cache: false,
	                        type : "GET",
	                        dataType : "json",
	                        success: function(data) {
	                            response($.map(data, function(item) {
	                                var parsed = JSON.parse(item);
	                                var sn = parsed.attributes.sn;
	                                var fn = parsed.attributes.givenName;
	                                var namestring = sn + ", " + fn;
	                                return namestring;
	                            }));
	                        }
	                    };
	                    $.ajax(url + "?" +
	                           $.param({"lastname": request.term,
	                                    "firstname": $("#author-first-name-0").val()}
	                          ),settings);
	                },
	                focus: function() {
	                  // prevent value inserted on focus
	                    return false;
	                },
	                select: function( event, ui ) {
	                    var name = ui.item.value;
	                    var sn = name.split(",")[0].trim();
	                    var fn = name.split(",")[1].trim();
	                    $(this).val(sn);
	                    $(this).parent().children().eq(1).val(fn);
	                    return false;
	                },
	                minLength:1,
	            });

	        var authorsLabel = $("<label/>")
	            .attr("for","author")
	            .text("Authors: ");

	        var authorsFirstNameLabel = $("<label/>")
	            .attr("for","defaultAuthorFirstName")
	            .text("First name(s), e.g. John: ");

	        var authorsLastNameLabel = $("<label/>")
	            .attr("for","defaultAuthorLastName")
	            .text("Last name, e.g. Smith: ");

	        var defaultAuthor = ($("<div/>"))
	            .addClass("author")
	            .append(defaultAuthorLastName)
	            .append(defaultAuthorFirstName);

	        var authors = $("<div/>").attr("id","authors")
	            .append(authorsLastNameLabel)
	            .append(authorsFirstNameLabel)
	            .append(defaultAuthor);

	        var addAuthorButton = $("<button/>")
	            .addClass("btn btn-xs btn-default")
	            .attr("id","add-author-button")
	            .attr("type","button")
	            .attr("aria-label","Add author")
	            .bind("click",addAuthor);

	        addAuthorButton.append($("<i>")
	                       .addClass("fa fa-plus")
	                       .attr("aria-hidden","true"));
	        defaultAuthor.append(addAuthorButton);

	        function addAuthor() {
	            var newAuthor = ($("<div/>"));
	            var currcount = authorcount;
	            var lastName = $("<input/>")
	                .attr("class","author-last-name")
	                .attr("type","text")
	                .attr("id","author-last-name-" + authorcount)
	                .on("keydown", function(event) {
	                    if (event.keyCode === $.ui.keyCode.TAB &&
	                        $(this).autocomplete().data("ui-autocomplete").menu.active)
	                    {
	                        event.preventDefault();
	                    }
	                })
	                .autocomplete({
	                    source: function( request, response ) {
	                        var url = Jupyter.notebook.contents.base_url + "ldap";
	                        var settings = {
	                            processData : false,
	                            cache: false,
	                            type : "GET",
	                            dataType : "json",
	                            success: function(data) {
	                                response($.map(data, function(item) {
	                                    var parsed = JSON.parse(item);
	                                    var sn = parsed.attributes.sn;
	                                    var fn = parsed.attributes.givenName;
	                                    var namestring = sn + ", " + fn;
	                                    return namestring;
	                                }));
	                            }
	                        };
	                        $.ajax(url + "?" +
	                               $.param({"lastname": request.term,
	                                        "firstname": $("#author-first-name-" + currcount).val()}
	                              ),settings);
	                    },
	                    focus: function() {
	                      // prevent value inserted on focus
	                        return false;
	                    },
	                    select: function( event, ui ) {
	                        var name = ui.item.value;
	                        var sn = name.split(",")[0].trim();
	                        var fn = name.split(",")[1].trim();
	                        $(this).val(sn);
	                        $(this).parent().children().eq(1).val(fn);
	                        return false;
	                    },
	                    minLength:1,
	                });
	            var firstName = $("<input/>")
	                .attr("class","author-first-name")
	                .attr("type","text")
	                .attr("id","author-first-name-" + authorcount)
	                .on("keydown", function(event) {
	                    if (event.keyCode === $.ui.keyCode.TAB &&
	                        $(this).autocomplete().data("ui-autocomplete").menu.active)
	                    {
	                        event.preventDefault();
	                    }
	                })
	                .autocomplete({
	                    source: function( request, response ) {
	                        var url = Jupyter.notebook.contents.base_url + "ldap";
	                        var settings = {
	                            processData : false,
	                            cache: false,
	                            type : "GET",
	                            dataType : "json",
	                            success: function(data) {
	                                response($.map(data, function(item) {
	                                    var parsed = JSON.parse(item);
	                                    var sn = parsed.attributes.sn;
	                                    var fn = parsed.attributes.givenName;
	                                    var namestring = sn + ", " + fn;
	                                    return namestring;
	                                }));
	                            }
	                        };
	                        $.ajax(url + "?" +
	                               $.param({"firstname": request.term,
	                                        "lastname": $("#author-last-name-" + currcount).val()}
	                              ),settings);
	                    },
	                    focus: function() {
	                      // prevent value inserted on focus
	                        return false;
	                    },
	                    select: function( event, ui ) {
	                        var name = ui.item.value;
	                        var sn = name.split(",")[0].trim();
	                        var fn = name.split(",")[1].trim();
	                        $(this).val(fn);
	                        $(this).parent().children().eq(0).val(sn);
	                        return false;
	                    },
	                    minLength:1,
	                });
	            newAuthor.addClass("author")
	                .append(lastName)
	                .append(firstName);
	            var previousAuthor = $(".author").last();

	            //detach from the previously last author input
	            //so we can put it back on the new one
	            addAuthorButton.detach(); 
	            var deleteAuthor = $("<button/>")
	                .addClass("btn btn-xs btn-default remove-author-button")
	                .attr("type","button")
	                .attr("aria-label","Remove author")
	                    .click(function() {
	                        previousAuthor.remove();
	                        $(this).remove();
	                    }); //add a remove button to the previously last author

	            deleteAuthor.append($("<i>")
	                        .addClass("fa fa-trash")
	                        .attr("aria-hidden","true"));
	            previousAuthor.append(deleteAuthor);
	            authors.append(newAuthor.append(addAuthorButton));
	            authorcount++;
	            return [lastName,firstName,newAuthor];
	        }

	        var abstractLabel = $("<label/>")
	            .attr("for","abstract")
	            .text("Abstract: ");

	        var abstract = $("<textarea/>").attr("name","abstract").attr("id","abstract");

	        var tagsLabel = $("<label/>")
	            .attr("for","tags")
	            .text("Tags: ");

	        var tags = $("<textarea/>").attr("name","tags").attr("id","tags");

	        var dateLabel = $("<label/>")
	            .attr("for","date")
	            .text("Date: ");

	        var date = $("<table/>").attr("id","date");

	        var yearLabel = $("<label/>")
	            .attr("for","year")
	            .text("Year: ")
	            .attr("id","year-label");
	        var year = $("<input/>").attr("name","year").attr("id","year");

	        var monthLabel = $("<label/>")
	            .attr("for","month")
	            .text("Month: ")
	            .attr("id","month-label");
	        var month = $("<select/>").attr("name","month").attr("id","month")
	            .append($("<option/>").attr("value","0").text(""))
	            .append($("<option/>").attr("value","1").text("January"))
	            .append($("<option/>").attr("value","2").text("February"))
	            .append($("<option/>").attr("value","3").text("March"))
	            .append($("<option/>").attr("value","4").text("April"))
	            .append($("<option/>").attr("value","5").text("May"))
	            .append($("<option/>").attr("value","6").text("June"))
	            .append($("<option/>").attr("value","7").text("July"))
	            .append($("<option/>").attr("value","8").text("August"))
	            .append($("<option/>").attr("value","9").text("September"))
	            .append($("<option/>").attr("value","10").text("October"))
	            .append($("<option/>").attr("value","11").text("November"))
	            .append($("<option/>").attr("value","12").text("December"));

	        var dayLabel = $("<label/>")
	            .attr("for","day")
	            .text("Day: ")
	            .attr("id","day-label");
	        var day = $("<input/>").attr("name","day").attr("id","day");

	        var dateLabelContainer = $("<tr/>").attr("id","date-label-container");
	        var dateInputContainer = $("<tr/>").attr("id","date-input-container");

	        dateLabelContainer.append($("<td>").append(yearLabel))
	                          .append($("<td>").append(monthLabel))
	                          .append($("<td>").append(dayLabel));

	        dateInputContainer.append($("<td>").append(year))
	                          .append($("<td>").append(month))
	                          .append($("<td>").append(day));

	        date.append(dateLabelContainer).append(dateInputContainer);

	        //TODO: Ask about type - surely it will have to be collection for now?


	        var languageLabel = $("<label/>")
	            .attr("for","language")
	            .text("Language: ");

	        var language = $("<select/>")
	            .attr("name","language")
	            .attr("id","language")
	            .append($("<option/>").attr("value","").text("n/A"))
	            .append($("<option/>").attr("value","en_US").text("English (US)"))
	            .append($("<option/>").attr("value","en").text("English"))
	            .append($("<option/>").attr("value","es").text("Spanish"))
	            .append($("<option/>").attr("value","de").text("German"))
	            .append($("<option/>").attr("value","fr").text("French"))
	            .append($("<option/>").attr("value","it").text("Italian"))
	            .append($("<option/>").attr("value","ja").text("Japanese"))
	            .append($("<option/>").attr("value","zh").text("Chinese"))
	            .append($("<option/>").attr("value","tr").text("Turkish"))
	            .append($("<option/>").attr("value","other").text("Other"));

	        var form1 = $("<fieldset/>").attr("title","fields1").attr("id","fields1")
	            .append(titleLabel)
	            .append(title)
	            .append(authorsLabel)
	            .append(authors)
	            .append(abstractLabel)
	            .append(abstract)
	            .append(tagsLabel)
	            .append(tags)
	            .append(dateLabel)
	            .append(date)
	            .append(languageLabel)
	            .append(language);            

	        var publisherLabel = $("<label/>")
	            .attr("for","publisher")
	            .text("Publisher: ");

	        var publisher = $("<input/>")
	            .attr("name","publisher")
	            .attr("id","publisher");

	        var citationLabel = $("<label/>")
	            .attr("for","citation")
	            .text("Citation: ");

	        var citation = $("<input/>")
	            .attr("name","citation")
	            .attr("id","citation");

	        var referencedByLabel = $("<label/>")
	            .attr("for","referencedBy")
	            .text("Related publication persistent URL: ");

	        var referencedBy = $("<input/>")
	            .addClass("referencedBy")
	            .attr("name","referencedBy")
	            .attr("id","referencedBy-0");

	        var referencedBy_div = $("<div/>").addClass("referencedBy_div");

	        var referencedBy_divs = $("<div/>");

	        var addURLButton = $("<button/>")
	            .addClass("btn btn-xs btn-default")
	            .attr("id","add-url-button")
	            .attr("type","button")
	            .bind("click",addURL)
	            .attr("aria-label","Add referenced By URL");

	        addURLButton.append($("<i>").addClass("fa fa-plus"));

	        referencedBy_div.append(referencedBy);
	        referencedBy_div.append(addURLButton);

	        referencedBy_divs.append(referencedBy_div);

	        var urlcount = 1;

	        function addURL() {
	            var newURL = ($("<div/>")).addClass("referencedBy_div");
	            var URL = $("<input/>")
	                .attr("class","referencedBy")
	                .attr("type","text")
	                .attr("id","referencedBy-" + urlcount);

	            var previousURL = $(".referencedBy_div").last();

	            //detach from the previously last url input
	            //so we can put it back on the new one
	            addURLButton.detach(); 
	            var deleteURL = $("<button/>")
	                .addClass("btn btn-xs btn-default remove-url-button")
	                .attr("type","button")
	                .attr("aria-label","Remove referenced By URL")
	                    .click(function() {
	                        previousURL.remove();
	                        $(this).remove();
	                    }); //add a remove button to the previously last url

	            deleteURL.append($("<i>")
	                             .addClass("fa fa-trash")
	                             .attr("aria-hidden","true"));
	            previousURL.append(deleteURL);
	            referencedBy_divs.append(newURL.append(URL).append(addURLButton));
	            urlcount++;

	            return [URL,newURL];
	        }

	        var fundersLabel = $("<label/>")
	            .attr("for","funders")
	            .text("Funders: ");

	        var funders = $("<input/>")
	            .attr("name","funders")
	            .attr("id","funders");         

	        var sponsorsLabel = $("<label/>")
	            .attr("for","sponsors")
	            .text("Sponsors: ");

	        var sponsors = $("<textarea/>")
	            .attr("name","sponsors")
	            .attr("id","sponsors");

	        var repositoryLabel = $("<label/>") //TODO: it this the most sensible place to  put this? perhaps before upload?
	            .attr("for","repository")
	            .text("Repository: ");

	        var repository = $("<select/>")
	            .attr("name","repository")
	            .attr("id","repository")
	            .append($("<option/>").attr("value","").text(""));

	        custom_contents.get_collections().then(function(response) {
	            var collections = JSON.parse(response);
	            collections.forEach(function(collection) {
	                var collection_option = $("<option/>");
	                collection_option.attr("value",collection.handle);
	                collection_option.text(collection.name);
	                repository.append(collection_option);
	            });

	            if(md_set) {
	                repository.val(md.reportmetadata.repository);
	            }
	            $(document.body).append($("<div/>").attr("id","collections_loaded"));
	        },function(reason) { //error
	            console.log("Error fetching collections from eData: ");
	            console.log(reason.xhr);
	            var repository_fetch_error = $("<div/>")
	                .addClass("repository-fetch-error")
	                .text("Couldn't download the repository information from eData." +
	                      " Please reload and if the error persists contact the developers.");
	            $("label[for=\"abstract\"]").after(repository_fetch_error);
	        });

	        var form2 = $("<fieldset/>").addClass("hide-me").attr("title","fields2").attr("id","fields2")
	            .append(publisherLabel)
	            .append(publisher)
	            .append(citationLabel)
	            .append(citation)
	            .append(referencedByLabel)
	            .append(referencedBy_divs)
	            .append(fundersLabel)
	            .append(funders)
	            .append(sponsorsLabel)
	            .append(sponsors)
	            .append(repositoryLabel)
	            .append(repository);


	        if(md_set) { //repopulate the form fields with previously saved data
	            title.val(md.reportmetadata.title);
	            var authorsarr = md.reportmetadata.authors;
	            var deleteAuthor;
	            authorsarr.forEach(function(item,index) {
	                if(index === 0) {
	                    defaultAuthorLastName.val(item[0]);
	                    defaultAuthorFirstName.val(item[1]);
	                    if(authorsarr.length > 1) {
	                        deleteAuthor = $("<button/>")
	                            .addClass("btn btn-xs btn-default remove-author-button")
	                            .attr("type","button")
	                            .attr("aria-label","Remove author")
	                                .click(function() {
	                                    auth[2].remove();
	                                    $(this).remove();
	                                }); //add a remove button to the previously last author

	                        deleteAuthor.append($("<i>")
	                                            .addClass("fa fa-trash")
	                                            .attr("aria-hidden","true"));
	                        defaultAuthor.append(deleteAuthor);
	                    }
	                    
	                } else {
	                    var auth = addAuthor();
	                    auth[0].val(item[0]);
	                    auth[1].val(item[1]);
	                    if(index !== authorsarr.length - 1) { //if not last element
	                        deleteAuthor = $("<button/>")
	                            .addClass("btn btn-xs btn-default remove-author-button")
	                            .attr("type","button")
	                            .attr("aria-label","Remove author")
	                                .click(function() {
	                                    auth[2].remove();
	                                    $(this).remove();
	                                }); //add a remove button to the previously last author

	                        deleteAuthor.append($("<i>")
	                                            .addClass("fa fa-trash")
	                                            .attr("aria-hidden","true"));
	                        auth[2].append(deleteAuthor);
	                    }
	                    //TODO: make this nicer? make it so I don"t have to manually add the delete?
	                }
	            });

	            abstract.val(md.reportmetadata.abstract);

	            md.reportmetadata.tags.forEach(function(item) {
	                tags.val(tags.val() + item + "\n");
	            });

	            var datearr = md.reportmetadata.date.split("-");
	            year.val(datearr[0]);
	            if(datearr.length > 1) { //if month and day have been saved check for them
	                //need to strip month of leading zero
	                if(datearr[1].charAt(0) === "0") {
	                    //leading 0, so only take last character
	                    datearr[1] = datearr[1].charAt(1);
	                }
	                month.val(datearr[1]);
	                day.val(datearr[2]);
	            }

	            language.val(md.reportmetadata.language);
	            publisher.val(md.reportmetadata.publisher);
	            citation.val(md.reportmetadata.citation);

	            var URLarr = md.reportmetadata.referencedBy;
	            var deleteURL;
	            URLarr.forEach(function(item,index) {
	                if(index === 0) {
	                    referencedBy.val(item);
	                    if(URLarr.length > 1) {
	                        //need to manually add delete button since addAuthor
	                        //relies on finding the previous author using selectors,
	                        //which don"t work here since the modal
	                        //is still being created I think...
	                        deleteURL = $("<button/>") 
	                            .addClass("btn btn-xs btn-default remove-url-button") 
	                            .attr("type","button")
	                            .attr("aria-label","Remove referenced By URL")
	                                .click(function() {
	                                    referencedBy.remove();
	                                    $(this).remove();
	                                });
	                        deleteURL.append($("<i>")
	                                         .addClass("fa fa-trash")
	                                         .attr("aria-hidden","true"));
	                        referencedBy_div.append(deleteURL);
	                    }
	                    
	                } else {
	                    var URL = addURL();
	                    URL[0].val(item);
	                    if(index !== URLarr.length - 1) { //if not last element
	                        deleteURL = $("<button/>")
	                            .addClass("btn btn-xs btn-default remove-url-button")
	                            .attr("type","button")
	                            .attr("aria-label","Remove referenced By URL")
	                                .click(function() {
	                                    URL[1].remove();
	                                    $(this).remove();
	                                });
	                        deleteURL.append($("<i>")
	                                         .addClass("fa fa-trash")
	                                         .attr("aria-hidden","true"));
	                        URL[1].append(deleteURL);
	                    }
	                }
	            });

	            funders.val(md.reportmetadata.funders);
	            sponsors.val(md.reportmetadata.sponsors);
	        }

	        return {form1: form1, form2: form2};
	    };

	    var validate_fields1 = function() {
	        var md = Jupyter.notebook.metadata;
	        $(".metadata-form-error").remove(); //clear errors

	        if($("#title").val() === "") {
	            var title_error = $("<div/>")
	                .attr("id","title-missing-error")
	                .addClass("metadata-form-error")
	                .text("Please enter a title");

	            $('label[for="title"]').after(title_error);
	        }
	        if($("#abstract").val() === "") {
	            var abstract_error = $("<div/>")
	                .attr("id","abstract-missing-error")
	                .addClass("metadata-form-error")
	                .text("Please enter an abstract");

	            $('label[for="abstract"]').after(abstract_error);
	        }
	        var isInteger = function(str,greaterthan,lessthan) {
	            var n = ~~Number(str); //convert into a number with no decimal part
	            return String(n) === str && n > greaterthan && n < lessthan;
	        };
	        var validDate = function(daystr,month,yearstr) {
	            if(!isInteger(daystr,0,32)) {
	                return false;
	            }
	            var day = Number(daystr); 
	            var year = Number(yearstr); //should be an int from the above checks

	            var monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
	            // Adjust for leap years
	            if(year % 400 === 0 || (year % 100 !== 0 && year % 4 === 0)) {
	                monthLength[1] = 29;
	            }
	            return day > 0 && day <= monthLength[month - 1];
	        };

	        //date checking. else ifs because previous errors affect later errors
	        //(e.g. invalid year affects day validity etc)
	        if($("#year").val() === "") {
	            var no_year_error = $("<div/>")
	                .attr("id","year-missing-error")
	                .addClass("metadata-form-error")
	                .text("Please enter at least the year of publication");

	            $('label[for="date"]').after(no_year_error);
	        } else if(!isInteger($("#year").val(),1800,3000)) {
	            var bad_year_error = $("<div/>")
	                .attr("id","invalid-year-error")
	                .addClass("metadata-form-error")
	                .text("Please enter a valid year");

	            $('label[for="date"]').after(bad_year_error);
	        } else if($("#day").val() !== "" && $("#month").val() === "0") {
	            var month_error = $("<div/>")
	                .attr("id","month-missing-error")
	                .addClass("metadata-form-error")
	                .text("Please select a month");

	            $('label[for="date"]').after(month_error);
	        } else if($("#day").val() !== "" &&
	                  !validDate($("#day").val(),$("#month").val(),$("#year").val()))
	        {
	            var day_error = $("<div/>")
	                .attr("id","invalid-day-error")
	                .addClass("metadata-form-error")
	                .text("Please enter valid day");

	            $('label[for="date"]').after(day_error);
	        }
	        $(".metadata-form-error").css("color", "red");
	    };

	    var validate_fields2 = function() {
	        var md = Jupyter.notebook.metadata;
	        $(".metadata-form-error").remove(); //clear errors

	        if($("#repository").val() === "") {
	            var repository_error = $("<div/>")
	                .attr("id","repository-missing-error")
	                .addClass("metadata-form-error")
	                .text("Please select a repository to deposit to");

	            $('label[for="repository"]').after(repository_error);
	        }

	        $(".metadata-form-error").css("color", "red");

	        if($(".metadata-form-error").length === 0) {
	            md.reportmetadata = {};
	            md.reportmetadata.title = $("#title").val();

	            md.reportmetadata.authors = [];
	            $(".author").each(function(i,e) {
	                var authorarr = [];
	                var ln = $(e).children(".author-last-name").val();
	                var fn = $(e).children(".author-first-name").val();
	                if(ln !== "" || fn !== "") {
	                    authorarr.push(ln);
	                    authorarr.push(fn);
	                    md.reportmetadata.authors.push(authorarr);
	                }
	            });
	            md.reportmetadata.abstract = $("#abstract").val();

	            //Split our textarea by lines
	            var split = $("#tags").val().split("\n");
	            var lines = [];
	            for (var i = 0; i < split.length; i++) {
	                if (split[i]) { //make sure we don"t add any empty lines!
	                    lines.push(split[i]);
	                }
	            }
	            md.reportmetadata.tags = lines;

	            var monthstring = "";
	            if ($("#month").val() < 10) {
	                //we need a leading zero to match DSpace's date format
	                monthstring = "0" + $("#month").val();
	            } else {
	                monthstring = $("#month").val();
	            }
	            if(monthstring === "00") { //if no month set it to just be the year
	                md.reportmetadata.date = $("#year").val();
	            } else if ($("#day").val() === "") { //month is set but day isn"t
	                md.reportmetadata.date = $("#year").val() + "-" + monthstring;
	            } else {
	                md.reportmetadata.date = $("#year").val() + "-" + monthstring +
	                                         "-" + $("#day").val();
	            }

	            md.reportmetadata.language = $("#language").val();
	            md.reportmetadata.publisher = $("#publisher").val();
	            md.reportmetadata.citation = $("#citation").val();
	            
	            md.reportmetadata.referencedBy = [];
	            $(".referencedBy").each(function(i,e) {
	                if($(e).val() !== "") {
	                    md.reportmetadata.referencedBy.push($(e).val());
	                }
	            });

	            md.reportmetadata.funders = $("#funders").val();
	            md.reportmetadata.sponsors = $("#sponsors").val();

	            md.reportmetadata.repository = $("#repository").val();

	            Jupyter.notebook.metadata = md;
	            Jupyter.notebook.save_notebook();
	            $("#collections_loaded").remove();
	        }
	    };

	    var validate = function() {
	        if(!$("#fields1").hasClass("hide-me") &&
	           $("#fields2").hasClass("hide-me"))
	        {
	            validate_fields1();
	            if($(".metadata-form-error").length === 0) {
	                $("#fields1").addClass("hide-me");
	                $("#fields2").removeClass("hide-me");
	                $("#previous").removeClass("disabled");

	                //we want button text to be save on the last page
	                $("#next").text("Save");
	            }
	        }
	        else if($("#fields1").hasClass("hide-me") &&
	                !$("#fields2").hasClass("hide-me"))
	        { //save our metadata
	            validate_fields2();
	            if($(".metadata-form-error").length === 0) {
	                $(".modal").modal("hide");
	            }
	        }
	    };
	   

	    var action = {
	        help: "Add notebook metadata",
	        help_index: "a",
	        icon: "fa-bars",
	        handler : add_metadata,
	    };

	    var prefix = "linker_extension";
	    var action_name = "add-notebook-metadata";

	    var load = function () {
	        Jupyter.actions.register(action,action_name,prefix);
	        $("#add_metadata").click(function () {
	            add_metadata();
	        });
	    };

	    module.exports = {
	        load: load,
	        validate: validate,
	        validate_fields1: validate_fields1,
	        validate_fields2: validate_fields2,
	        create_fields: create_fields,
	    };
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ },
/* 7 */
/***/ function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_7__;

/***/ },
/* 8 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	    __webpack_require__(2),
	    __webpack_require__(3)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,utils){

	    var load = function() {
	        var menubar_container = $("#menubar-container").detach();
	        var menubar_container_container = $("<div/>")
	                                          .attr("id","menubar-container-container")
	                                          .addClass("container");
	        menubar_container_container.append(menubar_container);
	        $(".header-bar").after(menubar_container_container);

	        //make publish menu
	        var dropdown = $("<li/>").addClass("dropdown")
	            .append($("<a/>")
	                    .attr("href","#")
	                    .addClass("dropdown-toggle")
	                    .attr("data-toggle","dropdown")
	                    .text("Publish"));

	        dropdown.click(function () {
	            // The selected cell loses focus when the menu is entered, so we
	            // re-select it upon selection.
	            var i = Jupyter.notebook.get_selected_index();
	            Jupyter.notebook.select(i, false);
	        });
	        var dropdown_ul = $("<ul/>")
	            .attr("id","publish_menu")
	            .addClass("dropdown-menu");

	        dropdown.append(dropdown_ul);
	        $("ul.navbar-nav").append(dropdown);

	        var toggle_cell_references_bar_text = "";

	        if(Jupyter.notebook.metadata.celltoolbar !== "Linker Extension") {
	            toggle_cell_references_bar_text = "Show cell references toolbar";
	        } else {
	            toggle_cell_references_bar_text = "Hide cell references toolbar";
	        }

	        dropdown_ul.append($("<li/>").attr("id","add_metadata")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("Add Metadata")))

	                   .append($("<li/>").attr("id","sword_new_item")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("New SWORD item")))

	                   .append($("<li/>").addClass("divider"))

	                   .append($("<li/>").attr("id","select_data")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("Select associated data")))

	                   .append($("<li/>").attr("id","view_data")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("View associated data")))

	                   .append($("<li/>").attr("id","upload_data")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("Upload associated data")))
	 
	                   .append($("<li/>").addClass("divider"))

	                   .append($("<li/>").attr("id","toggle_cell_references_bar")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text(toggle_cell_references_bar_text)))

	                   .append($("<li/>").attr("id","generate_references")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("Generate references")))

	                   .append($("<li/>").addClass("divider"))

	                   .append($("<li/>").attr("id","publish_notebook")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("Publish Notebook")))

	                   .append($("<li/>").attr("id","publish_bundle")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("Publish associated data")))

	                   .append($("<li/>").attr("id","publish_notebook_and_bundle")
	                                     .append($("<a/>")
	                                             .attr("href","#")
	                                             .text("Publish Notebook and associated data")));

	        $("#download_pdf").remove();
	        var new_pdf_menu_item = $("<li>").attr("id","#download_pdf")
	                                         .append($("<a/>")
	                                                 .attr("href","#")
	                                                 .text("PDF via LaTeX (.pdf)"));

	        new_pdf_menu_item.click(function() {
	            var notebook_path = utils.encode_uri_components(Jupyter.notebook.notebook_path);
	            var url = utils.url_path_join(
	                Jupyter.notebook.base_url,
	                "nbconvert",
	                "pdf",
	                "custom_article",
	                notebook_path
	            ) + "?download=true";
	            
	            var w = window.open("", Jupyter._target);
	            if (Jupyter.notebook.dirty && Jupyter.notebook.writable) {
	                Jupyter.notebook.save_notebook().then(function() {
	                    w.location = url;
	                });
	            } else {
	                w.location = url;
	            }
	        });

	        $("#download_rst").after(new_pdf_menu_item);
	    };

	    module.exports = {load: load};
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ },
/* 9 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	    __webpack_require__(2),
	    __webpack_require__(10),
	    __webpack_require__(7),
	    __webpack_require__(11)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,celltoolbar,dialog,events) {
	    "use strict";


	    var load = function() {
	        var CellToolbar = celltoolbar.CellToolbar;

	        CellToolbar.prototype._rebuild = CellToolbar.prototype.rebuild;
	        CellToolbar.prototype.rebuild = function () {
	            events.trigger("toolbar_rebuild.CellToolbar", this.cell);
	            this._rebuild();
	        };

	        CellToolbar._global_hide = CellToolbar.global_hide;
	        CellToolbar.global_hide = function () {
	            CellToolbar._global_hide();
	            for (var i=0; i < CellToolbar._instances.length; i++) {
	                events.trigger("global_hide.CellToolbar",
	                               CellToolbar._instances[i].cell);
	            }
	        };

	        var example_preset = [];

	        CellToolbar.register_callback("linker_extension.add_reference_url",
	                                      add_reference_url);
	        example_preset.push("linker_extension.add_reference_url");

	        CellToolbar.register_preset("Linker Extension",
	                                    example_preset,
	                                    Jupyter.notebook);

	        var action = {
	            help: "Show/hide the cell references bar on all the cells ",
	            help_index: "g",
	            icon: "fa-eye",
	            handler : toggle_cell_references_bar,
	        };

	        var prefix = "linker_extension";
	        var action_name = "toggle-cell-references-bar";
	        Jupyter.actions.register(action,action_name,prefix);

	        $("#toggle_cell_references_bar").click(function () {
	            toggle_cell_references_bar();
	        });
	    };

	    var toggle_cell_references_bar = function() {
	        var CellToolbar = celltoolbar.CellToolbar;
	        if(Jupyter.notebook.metadata.celltoolbar !== "Linker Extension") {
	            CellToolbar.global_show();

	            CellToolbar.activate_preset("Linker Extension");
	            Jupyter.notebook.metadata.celltoolbar = "Linker Extension";

	            $("#toggle_cell_references_bar > a")
	                .text("Hide cell references bar");
	        } else {
	            CellToolbar.global_hide();
	            delete Jupyter.notebook.metadata.celltoolbar;
	            $("#toggle_cell_references_bar > a")
	                .text("Show cell references bar");
	        }
	    };

	    var add_reference_url = function(div, cell) {
	        var help_text = "Add the reference URLs that relate to this cell:\n";
	        var toolbar_container = $(div).addClass("cell-urls-container");

	        var URL_container = $("<div/>").addClass("cell-urls");
	        toolbar_container.append(help_text);
	        toolbar_container.append(URL_container);

	        var md_set = cell.metadata.hasOwnProperty("referenceURLs");
	        if(!md_set) {
	            cell.metadata.referenceURLs = [];
	        }

	        var base_referenceURL = $("<input/>")
	            .addClass("referenceURL referenceURL_" + cell.cell_id)
	            .attr("name","referenceURL");

	        var base_referenceURL_div = $("<div/>")
	            .addClass("referenceURL_div")
	            .addClass("referenceURL_div_" + cell.cell_id);

	        base_referenceURL_div.append(base_referenceURL);
	        var addURLButton = $("<button/>")
	            .addClass("btn btn-xs btn-default add-cell-url-button")
	            .attr("type","button")
	            .bind("click",addURL)
	            .attr("aria-label","Add reference URL");

	        addURLButton.append($("<i>").addClass("fa fa-plus"));
	        base_referenceURL_div.append(addURLButton);

	        URL_container.append(base_referenceURL_div);

	        //on focus switch into edit mode so we can type text normally
	        base_referenceURL.focus(function() {
	            Jupyter.keyboard_manager.edit_mode();
	        });

	        function update_metadata() {
	            cell.metadata.referenceURLs = [];
	            $(".referenceURL_" + cell.cell_id).each(function(i,e) {
	                if($(e).val()) {
	                    cell.metadata.referenceURLs.push($(e).val());
	                }
	            });
	        }

	        //save all values to metadata on change
	        base_referenceURL.change(function() {
	            update_metadata();
	        });

	        if(md_set) {
	            var URLarr = cell.metadata.referenceURLs;
	            var deleteURL;
	            URLarr.forEach(function(item,index) {
	                if(index === 0) {
	                    base_referenceURL.val(item);
	                    if(URLarr.length > 1) {
	                        deleteURL = $("<button/>")
	                            .addClass("btn btn-xs btn-default remove-cell-url-button")
	                            .attr("type","button")
	                            .attr("aria-label","Remove reference URL")
	                                .click(function() {
	                                    base_referenceURL.remove();
	                                    $(this).remove();

	                                    update_metadata();
	                                });
	                        deleteURL.append($("<i>")
	                                         .addClass("fa fa-trash")
	                                         .attr("aria-hidden","true"));
	                        base_referenceURL_div.append(deleteURL);
	                    }
	                    
	                } else {
	                    var URL = addURL();
	                    URL[0].val(item);
	                    if(index !== URLarr.length - 1) { //if not last element
	                        deleteURL = $("<button/>")
	                            .addClass("btn btn-xs btn-default remove-cell-url-button")
	                            .attr("type","button")
	                            .attr("aria-label","Remove reference URL")
	                                .click(function() {
	                                    URL[1].remove();
	                                    $(this).remove();

	                                    update_metadata();
	                                });
	                        deleteURL.append($("<i>")
	                                         .addClass("fa fa-trash")
	                                         .attr("aria-hidden","true"));
	                        URL[1].append(deleteURL);
	                    }
	                }
	            });
	        }

	        function addURL() {
	            var newURL = ($("<div/>"))
	                          .addClass("referenceURL_div")
	                          .addClass("referenceURL_div_" + cell.cell_id);
	            var URL = $("<input/>")
	                .attr("class","referenceURL referenceURL_" + cell.cell_id)
	                .attr("type","text")
	                .attr("name","referenceURL");

	            //on focus switch into edit mode so we can type text normally
	            URL.focus(function() {
	                Jupyter.keyboard_manager.edit_mode();
	            });

	            URL.change(function() { //save all values to metadata on change
	                update_metadata();
	            });

	            var previousURL = $(".referenceURL_div_" + cell.cell_id).last();

	            //detach from the previously last url input so
	            //we can put it back on the new one
	            addURLButton.detach(); 
	            var deleteURL = $("<button/>")
	                .addClass("btn btn-xs btn-default remove-cell-url-button")
	                .attr("type","button")
	                .attr("aria-label","Remove reference URL")
	                    .click(function() {
	                        previousURL.remove();
	                        $(this).remove();
	                        update_metadata();
	                    }); //add a remove button to the previously last url

	            deleteURL.append($("<i>")
	                             .addClass("fa fa-trash")
	                             .attr("aria-hidden","true"));
	            previousURL.append(deleteURL);
	            URL_container.append(newURL.append(URL).append(addURLButton));
	            return [URL,newURL];
	        }
	    };


	    module.exports = {load: load};
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ },
/* 10 */
/***/ function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_10__;

/***/ },
/* 11 */
/***/ function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_11__;

/***/ },
/* 12 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	    __webpack_require__(2),
	    __webpack_require__(3),
	    __webpack_require__(8)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,utils){
	    
	    var select_data = function () {
	        sessionStorage.setItem("bundle",Jupyter.notebook.notebook_path);

	        var parent = utils.url_path_split(Jupyter.notebook.notebook_path)[0];
	        window.open(utils.url_path_join(Jupyter.notebook.contents.base_url,
	                                        "tree",
	                                        utils.encode_uri_components(parent)),
	                    "_self");
	    };

	    

	    var action = {
	        help: "Select associated data",
	        help_index: "d",
	        icon: "fa-check-square-o",
	        handler : select_data,
	    };

	    var prefix = "linker_extension";
	    var action_name = "select-associated-data";

	    var load = function () {
	        Jupyter.actions.register(action,action_name,prefix);
	        $("#select_data").click(function() {
	            select_data();
	        });
	    };

	    module.exports = {load: load, select_data: select_data};

	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	    __webpack_require__(2),
	    __webpack_require__(3),
	    __webpack_require__(7),
	    __webpack_require__(5),
	    __webpack_require__(4),
	    __webpack_require__(14),
	    __webpack_require__(12),
	    __webpack_require__(8)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(
	    Jupyter,
	    utils,
	    dialog,
	    custom_utils,
	    custom_contents,
	    view_data,
	    select_data) {

	    var upload_data_dialog = function () {
	        var upload_data_info = upload_data_form();

	        var dialog_body = upload_data_info.dialog_body;

	        var login_fields = $("<div/>").attr("id","login-fields-upload-data");
	        var username_label = $("<label/>")
	            .attr("for","username")
	            .text("Username: ");
	        var username_field = $("<input/>").attr("id","username-upload-data");

	        var password_label = $("<label/>")
	            .attr("for","password")
	            .text("Password: ");
	        var password_field = $("<input/>")
	            .attr("id","password-upload-data")
	            .attr("type","password");

	        login_fields.append(username_label)
	                    .append(username_field)
	                    .append(password_label)
	                    .append(password_field);

	        dialog_body.append(login_fields);

	        var modal_obj = dialog.modal({
	            title: "Upload Associated Data",
	            body: dialog_body,
	            default_button: "Cancel",
	            buttons: {
	                Cancel: {},
	                Upload: { 
	                    class : "btn-primary",
	                    click: function() { //todo: remove this button or sort out username
	                        upload_data(
	                            $("#username-upload-data").val(),
	                            $("#password-upload-data").val(),
	                            upload_data_info.file_names,
	                            upload_data_info.file_paths,
	                            upload_data_info.file_types
	                        );
	                    }
	                },
	            },
	            notebook: Jupyter.notebook,
	            keyboard_manager: Jupyter.keyboard_manager,
	        });
	    };

	    var upload_data = function(username,password,file_names,file_paths,file_types) {
	        var md = Jupyter.notebook.metadata;
	        if ("databundle_url" in md) {
	            //already uploaded to dspace so... TODO: do we want to block them if it"s already been uplaoded? should I grey out the button?
	            custom_utils.create_alert("alert-warning",
	                                      "You have already uploaded the associate " +
	                                      "data for this notebook to eData and it " +
	                                      "will not be reuploaded.");
	        }
	        else if ("reportmetadata" in md && "databundle" in md) {
	            var stringauthors = [];
	            var authors = md.reportmetadata.authors;
	            authors.forEach(function(author) {
	                var authorstring = author[0] + ", " + author[1];
	                stringauthors.push(authorstring); 
	            });

	            var referencedBy_URLs = [];
	            $(".data_referencedBy").each(function(i,e) {
	                if($(e).val() !== "") {
	                    referencedBy_URLs.push($(e).val());
	                }
	            });

	            var data = JSON.stringify({
	                "username": username,
	                "password": password,
	                "notebookpath": Jupyter.notebook.notebook_path,
	                "file_names": file_names,
	                "file_paths": file_paths,
	                "file_types": file_types,
	                "abstract": $("#data_abstract").val(),
	                "referencedBy": referencedBy_URLs,
	                "title":md.reportmetadata.title,
	                "authors":stringauthors,
	                "tags":md.reportmetadata.tags,
	                "date":md.reportmetadata.date,
	                "language":md.reportmetadata.language,
	                "publisher":md.reportmetadata.publisher,
	                "citation":md.reportmetadata.citation,
	                "funders":md.reportmetadata.funders,
	                "sponsors":md.reportmetadata.sponsors,
	                "repository":md.reportmetadata.repository
	            });
	            
	            custom_contents.upload_data(data).then(
	                function(response) {
	                    var id = "";
	                    var xml_str = response.split("\n");
	                    xml_str.forEach(function(item) {
	                        if (item.indexOf("<atom:id>") !== -1) { // -1 means it"s not in the string
	                            var endtag = item.lastIndexOf("<");
	                            var without_endtag = item.slice(0,endtag);
	                            var starttag = without_endtag.indexOf(">");
	                            var without_starttag = without_endtag.slice(starttag + 1);
	                            id = without_starttag;
	                        }
	                    });
	                    md.databundle_url = id;
	                    Jupyter.notebook.save_notebook();
	                    custom_utils.create_alert("alert-success",
	                                              "Success! Item created in DSpace via SWORD!")
	                                .attr("item-id",id);
	                },
	                function(reason) {
	                    custom_utils.create_alert("alert-danger",
	                                              "Error! " + reason.message + 
	                                              ", please try again. If it " + 
	                                              "continues to fail please " + 
	                                              "contact the developers.");
	                }
	            );
	        } else { 
	            if (!("reportmetadata" in md)) {
	                custom_utils.create_alert("alert-danger",
	                                          "Error! No report metadata - please " +
	                                          " fill in the report metadata first.");
	            }
	            if(!("databundle" in md)) {
	                custom_utils.create_alert("alert-danger",
	                                          "Error! No data associated with this " +
	                                          "notebook. You must select data to " + 
	                                          "upload before you an upload it."); 
	            }
	        }
	    };
	    

	    var upload_data_form = function() {
	        var display_files = $("<div/>").append(
	            $("<p/>").addClass("bundle-message")
	                .text("These are the files currently associated with " + 
	                      Jupyter.notebook.notebook_name + " :")
	        ).append(
	            $("<br/>")
	        );

	        var view_data_info = view_data.view_data();

	        display_files.append(view_data_info.view_data_div);

	        var file_names = view_data_info.file_names;
	        var file_paths = view_data_info.file_paths;
	        var file_types = view_data_info.file_types;

	        var data_abstract_label = $("<label/>")
	            .attr("for","data_abstract")
	            .text("Please write an abstract here (You may want to write " +
	                  " something to describe each file in the bundle): ");

	        var data_abstract = $("<textarea/>")
	            .attr("name","data_abstract")
	            .attr("id","data_abstract");

	        var default_abstract = "";
	        file_names.forEach(function(item,index) {
	            if(file_types[index] === "file") {
	                default_abstract = default_abstract + item;
	                if(index < file_names.length -1) {
	                    default_abstract = default_abstract + "\n\n";
	                }
	            }
	        });

	        data_abstract.val(default_abstract);

	        var data_referencedBy_label = $("<label/>")
	            .attr("for","data_referencedBy")
	            .text("Related publication persistent URLs: ");

	        var data_referencedBy = $("<input/>")
	            .addClass("data_referencedBy")
	            .attr("name","data_referencedBy")
	            .attr("id","data_referencedBy-0");

	        var data_referencedBy_div = $("<div/>")
	            .addClass("data_referencedBy_div");

	        var addURLButton = $("<button/>").text("Add")
	            .addClass("btn btn-xs btn-default")
	            .attr("id","add-url-button")
	            .attr("type","button")
	            .bind("click",addURL);

	        data_referencedBy_div.append(data_referencedBy);
	        data_referencedBy_div.append(addURLButton);

	        var urlcount = 1;

	        var data_fields = $("<fieldset/>")
	            .attr("title","data_fields").attr("id","data_fields")
	            .append(data_abstract_label)
	            .append(data_abstract)
	            .append(data_referencedBy_label)
	            .append(data_referencedBy_div);

	        function addURL() {
	            var newURL = ($("<div/>")).addClass("data_referencedBy_div");
	            var URL = $("<input/>")
	                .attr("class","data_referencedBy")
	                .attr("type","text")
	                .attr("id","data_referencedBy-" + urlcount);

	            var previousURL = $(".data_referencedBy_div").last();
	            //detach from the previously last url input
	            // so we can put it back on the new one
	            addURLButton.detach();
	            var deleteURL = $("<button/>").text("Remove")
	                .addClass("btn btn-xs btn-default")
	                .attr("id","remove-url-button")
	                .attr("type","button")
	                    .click(function() {
	                        previousURL.remove();
	                        $(this).remove();
	                    }); //add a remove button to the previously last url

	            previousURL.append(deleteURL);
	            data_fields.append(newURL.append(URL).append(addURLButton));
	            urlcount++;
	            return [URL,newURL];
	        }

	        var select_data_button = $("<button/>")
	            .addClass("btn btn-xs btn-default select-data-button")
	            .attr("type","button")
	            .text("Select data")
	            .attr("title","Select data to associate with this notebook")
	            .attr("aria-label","Select data to associate with this notebook")
	            .click(function() {
	                select_data.select_data();
	            });

	        var dialog_body = $("<div/>")
	            .append(display_files)
	            .append(select_data_button)
	            .append(data_fields);

	        return {dialog_body: dialog_body,
	                file_names: file_names,
	                file_paths: file_paths, 
	                file_types: file_types};
	    };
	    
	    var action = {
	        help: "Upload associated data",
	        help_index: "b",
	        icon: "fa-upload",
	        handler : upload_data_dialog,
	    };

	    var prefix = "linker_extension";
	    var action_name = "upload-associated-data";

	    var load = function () {
	        Jupyter.actions.register(action,action_name,prefix);
	        $("#upload_data").click(function () {
	            upload_data_dialog();
	        });
	    };

	    module.exports = {
	        load: load, 
	        upload_data_form: upload_data_form,
	        upload_data: upload_data,
	    };
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	    __webpack_require__(2),
	    __webpack_require__(7),
	    __webpack_require__(3),
	    __webpack_require__(8)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,dialog,utils){
	    
	    var view_data_dialog = function () {
	        var dialog_body = $("<div/>").append(
	            $("<p/>").addClass("bundle-message")
	                .text("These are the files currently associated with " + 
	                      Jupyter.notebook.notebook_name + " :")
	        ).append(
	            $("<br/>")
	        ).append(
	            view_data().view_data_div
	        );

	        var d = dialog.modal({
	            title : "View Associated Data",
	            body : dialog_body,
	            default_button: "OK",
	            buttons : {
	                OK: {}
	            },
	        });
	    };

	    var view_data = function() {
	        var view_data_div = $("<div/>").attr("id","view_data_container");
	        var file_names = [];
	        var file_paths = [];
	        var file_types = [];

	        if(!($.isEmptyObject(Jupyter.notebook.metadata))) {
	            if("databundle" in Jupyter.notebook.metadata) {
	                var databundle = Jupyter.notebook.metadata.databundle;
	                var bundlehtml = $("<div/>");
	                var type_order = {"directory":0,"notebook":1,"file":2};
	                var db_copy = databundle.slice();
	                db_copy.sort(function(a,b) {
	                    if (type_order[a.type] < type_order[b.type]) {
	                        return -1;
	                    }
	                    if (type_order[a.type] > type_order[b.type]) {
	                        return 1;
	                    }
	                    if (a.path.toLowerCase() < b.path.toLowerCase()) {
	                        return -1;
	                    }
	                    if (a.path.toLowerCase() > b.path.toLowerCase()) {
	                        return 1;
	                    }
	                    return 0;
	                });
	                var divs = {};
	                db_copy.forEach(function(item) {
	                    var div = $("<div/>")
	                        .text(item.path)
	                        .attr("data-indent",0)
	                        .attr("class","bundle-item")
	                        .css("margin-left","0px");

	                    if(item.type === "directory") {
	                        divs[item.path] = div;
	                    }
	                    if(divs.hasOwnProperty(utils.url_path_split(item.path)[0])){
	                        var parent = utils.url_path_split(item.path)[0];
	                        var indent = divs[parent].attr("data-indent") + 1;

	                        div.text(item.name)
	                           .attr("data-indent",indent)
	                           .css("margin-left","12px");

	                        divs[parent].append(div);
	                    } else {
	                        bundlehtml.append(div);
	                    }
	                    file_names.push(item.name);
	                    file_paths.push(item.path);
	                    file_types.push(item.type);
	                });
	                view_data_div.append(bundlehtml);
	            } else {
	                view_data_div.append($("<div/>")
	                                     .text("You have associated no files " + 
	                                           "with this notebook!"));
	            }
	            if("databundle_url" in Jupyter.notebook.metadata) {
	                view_data_div.append($("<br/>"));
	                view_data_div.append($("<strong/>")
	                                     .text("ATTENTION: ")
	                                     .css("color","red"));
	                view_data_div.append($("<p/>")
	                                     .text("You have already uploaded the " + 
	                                           "associated data for this notebook. " +
	                                           "It is located here: "));
	                view_data_div.append($("<a/>")
	                                     .attr("href",Jupyter.notebook.metadata.databundle_url)
	                                     .text(Jupyter.notebook.metadata.databundle_url));
	            }
	        } else {
	            view_data_div.append($("<div/>")
	                                 .text("You have associated no files" + 
	                                       "with this notebook!"));
	        }
	        return {view_data_div: view_data_div,
	                file_names: file_names,
	                file_paths: file_paths,
	                file_types: file_types};
	    };
	    
	    var action = {
	        help: "View associated data",
	        help_index: "c",
	        icon: "fa-eye",
	        handler : view_data,
	    };

	    var prefix = "linker_extension";
	    var action_name = "view-associated-data";
	    
	    var load = function () {
	        Jupyter.actions.register(action,action_name,prefix);
	        $("#view_data").click(function () {
	            view_data_dialog();
	        });
	    };

	    module.exports = {load: load, view_data: view_data};
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	    __webpack_require__(2),
	    __webpack_require__(3),
	    __webpack_require__(7),
	    __webpack_require__(5),
	    __webpack_require__(4),
	    __webpack_require__(8)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,utils,dialog,custom_utils,custom_contents){

	    var upload_notebook = function(username,password) {
	        if ("reportmetadata" in Jupyter.notebook.metadata) {
	            var stringauthors = [];
	            var authors = Jupyter.notebook.metadata.reportmetadata.authors;
	            authors.forEach(function(author) {
	                var authorstring = author[0] + ", " + author[1];
	                stringauthors.push(authorstring); 
	            });

	            var data = JSON.stringify({
	                "username": username,
	                "password": password,
	                "notebookpath": Jupyter.notebook.notebook_path,
	                "title":Jupyter.notebook.metadata.reportmetadata.title,
	                "authors":stringauthors,
	                "abstract":Jupyter.notebook.metadata.reportmetadata.abstract,
	                "tags":Jupyter.notebook.metadata.reportmetadata.tags,
	                "date":Jupyter.notebook.metadata.reportmetadata.date,
	                "language":Jupyter.notebook.metadata.reportmetadata.language,
	                "publisher":Jupyter.notebook.metadata.reportmetadata.publisher,
	                "citation":Jupyter.notebook.metadata.reportmetadata.citation,
	                "referencedBy":Jupyter.notebook.metadata.reportmetadata.referencedBy,
	                "funders":Jupyter.notebook.metadata.reportmetadata.funders,
	                "sponsors":Jupyter.notebook.metadata.reportmetadata.sponsors,
	                "repository":Jupyter.notebook.metadata.reportmetadata.repository
	            });
	            custom_contents.sword_new_item(data).then(
	                function(response) {
	                    var id = "";
	                    var xml_str = response.split("\n");
	                    xml_str.forEach(function(item) {
	                        if (item.indexOf("<atom:id>") !== -1) { // -1 means it"s not in the string
	                            var endtag = item.lastIndexOf("<");
	                            var without_endtag = item.slice(0,endtag);
	                            var starttag = without_endtag.indexOf(">");
	                            var without_starttag = without_endtag.slice(starttag + 1);
	                            id = without_starttag;
	                        }
	                    });
	                    custom_utils.create_alert("alert-success",
	                                              "Success! Item created in " + 
	                                              "DSpace via SWORD!")
	                                .attr("item-id",id);
	                },
	                function(reason) {
	                    custom_utils.create_alert("alert-danger",
	                                              "Error! " + reason.message + 
	                                              ", please try again. If it " +
	                                              "continues to fail please " + 
	                                              "contact the developers.");
	                }
	                //TODO: aim the error messages at the user and not me
	            );
	        } else {
	            custom_utils.create_alert("alert-danger",
	                                      "Error! No metadata found. Please use " +
	                                      "the \"Add Metadata\" menu item to add " +
	                                      "the metadata for this report");
	        }
	    };

	    var upload_notebook_dialog = function() {
	        var login_fields = $("<div/>").attr("id","login-fields-new-item");
	        var username_label = $("<label/>")
	            .attr("for","username")
	            .text("Username: ");
	        var username_field = $("<input/>").attr("id","username-new-item");

	        var password_label = $("<label/>")
	            .attr("for","password")
	            .text("Password: ");
	        var password_field = $("<input/>")
	            .attr("id","password-new-item")
	            .attr("type","password");

	        login_fields.append(username_label)
	                    .append(username_field)
	                    .append(password_label)
	                    .append(password_field);

	        var d = dialog.modal({
	            title: "Upload Notebook",
	            body: login_fields,
	            default_button: "Cancel",
	            buttons: {
	                Upload:  {
	                    class : "btn-primary",
	                    click: function() {
	                        upload_notebook($("#username-new-item").val(),
	                                        $("#password-new-item").val());
	                    }
	                },
	                Cancel: {},
	            },
	            notebook: Jupyter.notebook,
	            keyboard_manager: Jupyter.keyboard_manager,
	        });
	    };
	    
	    var action = {
	        help: "Upload notebook",
	        help_index: "e",
	        icon: "fa-upload",
	        handler : upload_notebook,
	    };

	    var prefix = "linker_extension";
	    var action_name = "upload-notebook-data";

	    var load = function () {
	        Jupyter.actions.register(action,action_name,prefix);
	        $("#sword_new_item").click(function () {
	            upload_notebook_dialog();
	        });
	    };

	    module.exports = {load: load, upload_notebook: upload_notebook};
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ },
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(2),
	        __webpack_require__(3),
	        __webpack_require__(7),
	        __webpack_require__(4),
	        __webpack_require__(14),
	        __webpack_require__(6),
	        __webpack_require__(12),
	        __webpack_require__(15),
	        __webpack_require__(13),
	        __webpack_require__(8)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,
	           utils,
	           dialog,
	           custom_contents,
	           view_data,
	           add_metadata,
	           select_data,
	           upload_notebook,
	           upload_data) {

	    //Publish. Gives users a last chance to add metadata or associate files
	    //before uploading notebook and data to dspace.

	    var publish_notebook_and_bundle = function() {
	        var add_metadata_form_fields = add_metadata.create_fields();
	        add_metadata_form_fields.form1.addClass("hide-me");
	        add_metadata_form_fields.form2.addClass("hide-me");

	        var instructions = $("<label/>")
	            .attr("id","publish_instructions")
	            .attr("for","publish_form");

	        instructions.text("Check the files currently associated with this " + 
	                          "notebook and add additional metadata for the zip " + 
	                          "file contianing all the following files. Click the " +
	                          "\"Select Data\" button to navigate away from this " + 
	                          "page to select additional data to associate with " +
	                          "this notebook");

	        var upload_data_info = upload_data.upload_data_form(); 

	        var upload_data_container = $("<div/>")
	            .attr("id","upload-data-container")
	            .append(upload_data_info.dialog_body);

	        var form_body = $("<div/>").attr("title", "Publish notebook")
	        .append(
	            $("<form id=\"publish_form\"/>")
	                    .append(instructions)
	                    .append(upload_data_container)
	                    .append(add_metadata_form_fields.form1)
	                    .append(add_metadata_form_fields.form2)
	        );

	        var final_page = $("<div/>").attr("id","final-page");
	        final_page.addClass("hide-me");
	        
	        var login_fields = $("<div/>").attr("id","login-fields");
	        var username_label = $("<label/>")
	            .attr("for","username")
	            .text("Username: ");
	        var username_field = $("<input/>").attr("id","username");

	        var password_label = $("<label/>")
	            .attr("for","password")
	            .text("Password: ");
	        var password_field = $("<input/>")
	            .attr("id","password")
	            .attr("type","password");

	        login_fields.append(username_label)
	                    .append(username_field)
	                    .append(password_label)
	                    .append(password_field);

	        final_page.append(login_fields);

	        form_body.append(final_page);

	        var modal = dialog.modal({
	            title: "Publish Notebook",
	            body: form_body,
	            buttons: {
	                Cancel: {},
	                Previous: { 
	                    click: function() {
	                        //make a multi page form by changing visibility of the forms
	                        if(!$("#upload-data-container").hasClass("hide-me")) {
	                            //can"t go back when we"re on the first page
	                            $("#previous").addClass("disabled"); 
	                        } 
	                        else if($("upload-data-container").hasClass("hide-me") &&
	                                !$("#fields1").hasClass("hide-me"))
	                        {
	                            $("#fields1").addClass("hide-me");
	                            $("#upload-data-container").removeClass("hide-me");
	                            instructions.text("Check the files currently " +
	                                              "associated with this notebook. " +
	                                              "Click the \"Select Data\" button " +
	                                              "to navigate away from this page " +
	                                              "to select additional data to " +
	                                              "associate with this notebook");
	                        }
	                        else if($("#fields1").hasClass("hide-me") &&
	                                !$("#fields2").hasClass("hide-me"))
	                        {
	                            $("#fields2").addClass("hide-me");
	                            $("#fields1").removeClass("hide-me");
	                        }
	                        else if($("#fields2").hasClass("hide-me") &&
	                                !$("#final-page").hasClass("hide-me"))
	                        {
	                            $("#final-page").addClass("hide-me");
	                            $("#fields2").removeClass("hide-me");

	                            //we want button text to be next
	                            //on any page but the last one
	                            $("#next").text("Next");
	                        }
	                    }
	                },
	                Next: { 
	                    class : "btn-primary",
	                    click: function() {
	                        if(!$("#upload-data-container").hasClass("hide-me")) {
	                            var bundle_metadata = {};
	                            bundle_metadata.abstract = $("#data_abstract").val();
	                            var referencedBy_URLs = [];
	                            $(".data_referencedBy").each(function(i,e) {
	                                referencedBy_URLs.push($(e).val());
	                            });
	                            bundle_metadata.referencedBy = referencedBy_URLs;
	                            //TODO: do we need to save this metadata or not? ask

	                            $("#upload-data-container").addClass("hide-me");
	                            $("#fields1").removeClass("hide-me");
	                            $("#previous").removeClass("disabled");
	                            instructions.text("Check and edit the metadata for " +
	                                              "the notebook before uploading to eData.");

	                            Jupyter.notebook.metadata.bundle_metadata = bundle_metadata;
	                        } else if (!$("#fields1").hasClass("hide-me")) {
	                            add_metadata.validate_fields1();
	                            if($(".metadata-form-error").length === 0) {
	                                $("#fields1").addClass("hide-me");
	                                $("#fields2").removeClass("hide-me");
	                            }
	                        }  else if (!$("#fields2").hasClass("hide-me")) {
	                            add_metadata.validate_fields2();
	                            if($(".metadata-form-error").length === 0) {
	                                $("#fields2").addClass("hide-me");
	                                $("#final-page").removeClass("hide-me");

	                                //we want next to be publish on the last page
	                                $("#next").text("Publish");
	                            }
	                        }
	                        else if (!$("#final-page").hasClass("hide-me")) {
	                            //do login validation and publishing here!
	                            $(".login-error").remove();
	                            var login_details = JSON.stringify({
	                                username: $("#username").val(),
	                                password: $("#password").val()
	                            });

	                            var request = custom_contents.ldap_auth(login_details);

	                            request.then(
	                                function() { //success function
	                                    upload_notebook.upload_notebook(
	                                        $("#username").val(),
	                                        $("#password").val()
	                                    );

	                                    upload_data.upload_data(
	                                        $("#username").val(),
	                                        $("#password").val(),
	                                        upload_data_info.file_names,
	                                        upload_data_info.file_paths,
	                                        upload_data_info.file_types
	                                    );

	                                    $(".modal").modal("hide");
	                                },
	                                function(reason) { //fail function
	                                    var error = $("<div/>")
	                                        .addClass("login-error")
	                                        .css("color","red");

	                                    if (reason.xhr.status === 401) { //unauthorised
	                                        //you dun goofed on ur login
	                                        error.text("Login details not receognised.");
	                                        instructions.after(error);
	                                    } else if (reason.xhr.status === 400) { //unauthorised
	                                        //you dun goofed on ur login
	                                        error.text("Login details not valid.");
	                                        instructions.after(error);
	                                    } else {
	                                        //shouldn't really get here?
	                                        error.text("Login failed - please try again.");
	                                        instructions.after(error);
	                                    }
	                                }
	                            );
	                        }
	                    },
	                }
	            },
	            notebook: Jupyter.notebook,
	            keyboard_manager: Jupyter.notebook.keyboard_manager,
	        });

	        modal.on("shown.bs.modal", function () {
	            $(".modal-footer > button.btn-sm").eq(1).removeAttr("data-dismiss")
	                                                    .attr("id","previous");
	            $(".modal-footer > button.btn-sm").eq(2).removeAttr("data-dismiss")
	                                                    .attr("id","next");
	        });

	    };

	    var publish_notebook = function() {
	        var add_metadata_form_fields = add_metadata.create_fields();
	        add_metadata_form_fields.form2.addClass("hide-me");

	        var instructions = $("<label/>")
	            .attr("id","publish_instructions")
	            .attr("for","publish_form");

	        instructions.text("Check the files currently associated with this " + 
	                          "notebook and add additional metadata for the zip " + 
	                          "file contianing all the following files. Click the " +
	                          "\"Select Data\" button to navigate away from this " + 
	                          "page to select additional data to associate with " +
	                          "this notebook");

	        var form_body = $("<div/>").attr("title", "Publish notebook")
	        .append(
	            $("<form id=\"publish_form\"/>")
	                    .append(instructions)
	                    .append(add_metadata_form_fields.form1)
	                    .append(add_metadata_form_fields.form2)
	        );


	        var final_page = $("<div/>").attr("id","final-page");
	        final_page.addClass("hide-me");

	        var login_fields = $("<div/>").attr("id","login-fields");
	        var username_label = $("<label/>")
	            .attr("for","username")
	            .text("Username: ");
	        var username_field = $("<input/>").attr("id","username");

	        var password_label = $("<label/>")
	            .attr("for","password")
	            .text("Password: ");
	        var password_field = $("<input/>")
	            .attr("id","password")
	            .attr("type","password");

	        login_fields.append(username_label)
	                    .append(username_field)
	                    .append(password_label)
	                    .append(password_field);

	        final_page.append(login_fields);

	        form_body.append(final_page);

	        var modal = dialog.modal({
	            title: "Publish Notebook",
	            body: form_body,
	            buttons: {
	                Cancel: {},
	                Previous: { 
	                    click: function() {
	                        //make a multi page form by changing visibility of the forms
	                        if(!$("#fields1").hasClass("hide-me")) {
	                            //can't go back when we'"'re on the first page
	                            $("#previous").addClass("disabled");
	                        } 
	                        else if($("#fields1").hasClass("hide-me") &&
	                                !$("#fields2").hasClass("hide-me"))
	                        {
	                            $("#fields2").addClass("hide-me");
	                            $("#fields1").removeClass("hide-me");
	                        }
	                        else if($("#fields2").hasClass("hide-me") &&
	                                !$("#final-page").hasClass("hide-me"))
	                        {
	                            $("#final-page").addClass("hide-me");
	                            $("#fields2").removeClass("hide-me");

	                            //we want button text to be next
	                            //on any page but the last one
	                            $("#next").text("Next");
	                        }
	                    }
	                },
	                Next: { 
	                    class : "btn-primary",
	                    click: function() {
	                        if (!$("#fields1").hasClass("hide-me")) {
	                            add_metadata.validate_fields1();
	                            if($(".metadata-form-error").length === 0) {
	                                $("#fields1").addClass("hide-me");
	                                $("#fields2").removeClass("hide-me");
	                                $("#previous").removeClass("disabled");
	                            }
	                        }  else if (!$("#fields2").hasClass("hide-me")) {
	                            add_metadata.validate_fields2();
	                            if($(".metadata-form-error").length === 0) {
	                                $("#fields2").addClass("hide-me");
	                                $("#final-page").removeClass("hide-me");
	                                $("#next").text("Publish"); //we want next to be save on the last page
	                            }
	                        }
	                        else if (!$("#final-page").hasClass("hide-me")) {
	                            //do login validation and publishing here!
	                            $(".login-error").remove();
	                            var login_details = JSON.stringify({
	                                username: $("#username").val(),
	                                password: $("#password").val()
	                            });

	                            var request = custom_contents.ldap_auth(login_details);

	                            request.then(
	                                function() { //success function
	                                    upload_notebook.upload_notebook(
	                                        $("#username").val(),
	                                        $("#password").val()
	                                    );

	                                    $(".modal").modal("hide");
	                                },
	                                function(reason) { //fail function
	                                    var error = $("<div/>")
	                                        .addClass("login-error")
	                                        .css("color","red");

	                                    if (reason.xhr.status === 401) { //unauthorised
	                                        //you dun goofed on ur login
	                                        error.text("Login details not receognised.");
	                                        instructions.after(error);
	                                    } else if (reason.xhr.status === 400) { //unauthorised
	                                        //you dun goofed on ur login
	                                        error.text("Login details not valid.");
	                                        instructions.after(error);
	                                    } else {
	                                        //shouldn't really get here?
	                                        error.text("Login failed - please try again.");
	                                        instructions.after(error);
	                                    }
	                                }
	                            );
	                        }
	                    },
	                }
	            },
	            notebook: Jupyter.notebook,
	            keyboard_manager: Jupyter.notebook.keyboard_manager,
	        });

	        modal.on("shown.bs.modal", function () {
	            $(".modal-footer > button.btn-sm").eq(1).removeAttr("data-dismiss")
	                                                    .attr("id","previous");
	            $(".modal-footer > button.btn-sm").eq(2).removeAttr("data-dismiss")
	                                                    .attr("id","next");
	        });

	    };

	    var publish_bundle = function() {
	        var instructions = $("<label/>")
	            .attr("id","publish_instructions")
	            .attr("for","publish_form");

	        instructions.text("Check the files currently associated with this " + 
	                          "notebook and add additional metadata for the zip " + 
	                          "file contianing all the following files. Click the " +
	                          "\"Select Data\" button to navigate away from this " + 
	                          "page to select additional data to associate with " +
	                          "this notebook");

	        var upload_data_info = upload_data.upload_data_form(); 

	        var upload_data_container = $("<div/>")
	            .attr("id","upload-data-container")
	            .append(upload_data_info.dialog_body);

	        var form_body = $("<div/>").attr("title", "Publish data")
	        .append(
	            $("<form id=\"publish_form\"/>")
	                    .append(instructions)
	                    .append(upload_data_container)
	        );

	        var final_page = $("<div/>").attr("id","final-page");
	        final_page.addClass("hide-me");
	        
	        var login_fields = $("<div/>").attr("id","login-fields");
	        var username_label = $("<label/>")
	            .attr("for","username")
	            .text("Username: ");
	        var username_field = $("<input/>").attr("id","username");

	        var password_label = $("<label/>")
	            .attr("for","password")
	            .text("Password: ");
	        var password_field = $("<input/>")
	            .attr("id","password")
	            .attr("type","password");

	        login_fields.append(username_label)
	                    .append(username_field)
	                    .append(password_label)
	                    .append(password_field);

	        final_page.append(login_fields);
	        
	        form_body.append(final_page);

	        var modal = dialog.modal({
	            title: "Publish Notebook",
	            body: form_body,
	            buttons: {
	                Cancel: {},
	                Previous: { 
	                    click: function() {
	                        //make a multi page form by changing visibility of the forms
	                        if(!$("#upload-data-container").hasClass("hide-me")) {
	                            //can"t go back when we're on the first page
	                            $("#previous").addClass("disabled");
	                        } 
	                        else if($("upload-data-container").hasClass("hide-me") &&
	                                !$("#final-page").hasClass("hide-me"))
	                        {
	                            $("#final-page").addClass("hide-me");
	                            $("#upload-data-container").removeClass("hide-me");

	                            //we want button text to be next
	                            //on any page but the last one
	                            $("#next").text("Next");
	                        }
	                    }
	                },
	                Next: { 
	                    class : "btn-primary",
	                    click: function() {
	                        if(!$("#upload-data-container").hasClass("hide-me")) {
	                            var bundle_metadata = {};
	                            bundle_metadata.abstract = $("#data_abstract").val();
	                            var referencedBy_URLs = [];
	                            $(".data_referencedBy").each(function(i,e) {
	                                referencedBy_URLs.push($(e).val());
	                            });
	                            bundle_metadata.referencedBy = referencedBy_URLs;
	                            //TODO: do we need to save this metadata or not? ask

	                            Jupyter.notebook.metadata.bundle_metadata = bundle_metadata;

	                            $("#upload-data-container").addClass("hide-me");
	                            $("#final-page").removeClass("hide-me");
	                            $("#previous").removeClass("disabled");
	                            instructions.text("Confirm that you would like " + 
	                                              "to upload the data bundle.");

	                            //we want next to be publish on the last page
	                            $("#next").text("Publish");
	                        }

	                        else if (!$("#final-page").hasClass("hide-me")) {
	                            //do login validation and publishing here!
	                            $(".login-error").remove();
	                            console.log(login_details);
	                            var login_details = JSON.stringify({
	                                username: $("#username").val(),
	                                password: $("#password").val()
	                            });

	                            var request = custom_contents.ldap_auth(login_details);

	                            request.then(
	                                function() { //success function
	                                    upload_data.upload_data(
	                                        $("#username").val(),
	                                        $("#password").val(),
	                                        upload_data_info.file_names,
	                                        upload_data_info.file_paths,
	                                        upload_data_info.file_types
	                                    );

	                                    $(".modal").modal("hide");
	                                },
	                                function(reason) { //fail function
	                                    var error = $("<div/>")
	                                        .addClass("login-error")
	                                        .css("color","red");

	                                    if (reason.xhr.status === 401) { //unauthorised
	                                        //you dun goofed on ur login
	                                        error.text("Login details not receognised.");
	                                        instructions.after(error);
	                                    } else if (reason.xhr.status === 400) { //unauthorised
	                                        //you dun goofed on ur login
	                                        error.text("Login details not valid.");
	                                        instructions.after(error);
	                                    } else {
	                                        //shouldn't really get here?
	                                        error.text("Login failed - please try again.");
	                                        instructions.after(error);
	                                    }
	                                }
	                            );
	                        }
	                    },
	                }
	            },
	            notebook: Jupyter.notebook,
	            keyboard_manager: Jupyter.notebook.keyboard_manager,
	        });

	        modal.on("shown.bs.modal", function () {
	            $(".modal-footer > button.btn-sm").eq(1).removeAttr("data-dismiss")
	                                                    .attr("id","previous");
	            $(".modal-footer > button.btn-sm").eq(2).removeAttr("data-dismiss")
	                                                    .attr("id","next");
	        });

	    };

	    var publish_notebook_action = {
	        help: "Publish notebook",
	        help_index: "a",
	        icon: "fa-upload",
	        handler : publish_notebook,
	    };

	    var publish_notebook_prefix = "linker_extension";
	    var publish_notebook_action_name = "publish-notebook";
	    

	    var publish_bundle_action = {
	        help: "Publish data bundle",
	        help_index: "a",
	        icon: "fa-upload",
	        handler : publish_bundle,
	    };

	    var publish_bundle_prefix = "linker_extension";
	    var publish_bundle_action_name = "publish-bundle";

	    var publish_both_action = {
	        help: "Publish notebook and data bundle",
	        help_index: "a",
	        icon: "fa-upload",
	        handler : publish_notebook_and_bundle,
	    };

	    var publish_both_prefix = "linker_extension";
	    var publish_both_action_name = "publish-notebook-and-data-bundle";

	    var load = function () {
	        Jupyter.actions.register(
	            publish_notebook_action,
	            publish_notebook_action_name,
	            publish_notebook_prefix
	        );
	        $("#publish_notebook").click(function () {
	            publish_notebook();
	        });
	        Jupyter.actions.register(
	            publish_bundle_action,
	            publish_bundle_action_name,
	            publish_bundle_prefix
	        );
	        $("#publish_bundle").click(function () {
	            publish_bundle();
	        });
	        Jupyter.actions.register(
	            publish_both_action,
	            publish_both_action_name,
	            publish_both_prefix
	        );
	        $("#publish_notebook_and_bundle").click(function () {
	            publish_notebook_and_bundle();
	        });
	    };

	    module.exports = {
	        load: load,
	    };
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ },
/* 17 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	    __webpack_require__(2),
	    __webpack_require__(3),
	    __webpack_require__(5),
	    __webpack_require__(4),
	    __webpack_require__(8)
	], __WEBPACK_AMD_DEFINE_RESULT__ = function(Jupyter,utils,custom_utils){

	    var generate_references = function() {
	        var cells = Jupyter.notebook.get_cells(); 

	        //object can mimic set functionality - we only want one url
	        //to show up for a reference which may appear multiple times
	        //keys are the set items, values are just set to true.
	        var reference_urls = Object.create(null); 

	        if("databundle_url" in Jupyter.notebook.metadata) {
	            reference_urls[Jupyter.notebook.metadata.databundle_url] = true;
	        }
	        if("reportmetadata" in Jupyter.notebook.metadata) {
	            Jupyter.notebook.metadata.reportmetadata.referencedBy.forEach(
	                function(item) {
	                    reference_urls[item] = true;
	                }
	            );
	        }

	        //use loop to find our reference cell and if it's not our
	        //reference cell get the urls of it's indivudual references
	        cells.forEach(function(cell) { 
	            if (cell.metadata.reference_cell === true) {
	                var cell_index = Jupyter.notebook.find_cell_index(cell);
	                Jupyter.notebook.delete_cell(cell_index);
	            }
	            else {
	                if("referenceURLs" in cell.metadata) {
	                    cell.metadata.referenceURLs.forEach(function(item) {
	                        reference_urls[item] = true;
	                    });
	                }
	            }
	        });        

	        if (Object.keys(reference_urls).length > 0) {
	            var reference_cell = Jupyter.notebook.insert_cell_at_bottom("markdown");

	            var text = "## References\n";

	            Object.keys(reference_urls).forEach(function(reference) {
	                //markdown can use chevrons (< and >) to generate links
	                text = text +"<" + reference + ">\n\n";
	            });

	            reference_cell.set_text(text);
	            reference_cell.execute();

	            //can't use cell ids since they"re regenerated on load so
	            //put a bool in the reference cell metadata which we can search for
	            reference_cell.metadata.reference_cell = true;
	        } else { //no references - show alert to user to tell them
	            custom_utils.create_alert("alert-danger","Reference cell not generated " +
	                "since there are no references specified. Specify references" + 
	                " by adding them to the notebook metadata, using the cell " +
	                "reference toolbar to add references to specific cells or by" + 
	                " uploading a data bundle to DSpace from this notebook.");
	        }
	        
	    };

	    var action = {
	        help: "Generate references",
	        help_index: "f",
	        handler : generate_references,
	    };

	    var prefix = "linker_extension";
	    var action_name = "generate-references";
	    
	    var load = function () {
	        Jupyter.actions.register(action,action_name,prefix);
	        $("#generate_references").click(function () {
	            generate_references();
	        });
	    };

	    module.exports = {load: load};
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ }
/******/ ])});;